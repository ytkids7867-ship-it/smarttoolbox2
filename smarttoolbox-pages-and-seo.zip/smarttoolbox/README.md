# SmartToolbox

A responsive, static all-in-one tools website built with HTML, CSS and vanilla JavaScript.

## Included tools
- QR Code Generator
- Image Compressor (canvas export)
- PDF re-save utility (not guaranteed to reduce file size)
- JPG/PNG to PDF
- Image Resizer
- Word Counter
- Password Generator (Web Crypto API)
- Text Case Converter
- Age Calculator
- EMI Calculator (estimate only)

## Publish with GitHub Pages
1. Upload the contents of this folder to the root of your `smarttoolbox` repository (not the ZIP itself).
2. In GitHub, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch `main` and folder `/ (root)`, then Save.
5. Wait for the Pages deployment workflow to finish successfully.
6. Open `https://ytkids7867-ship-it.github.io/smarttoolbox/`.

If you prefer GitHub Actions, use the official Pages workflow and ensure the repository has Pages configured for GitHub Actions. Do not mix a branch-based deployment and an incompatible custom workflow.

## Before launch
- Confirm the public website URL and canonical URL are correct.
- Add a real contact email to `contact.html`.
- Test all tools on desktop and mobile.
- Confirm all third-party CDN scripts load.
- Add original explanatory content for each tool before pursuing SEO.
- Review GitHub Pages terms for your intended advertising-supported use and obtain clarification from GitHub if needed.
- Do not add Adsterra code until the site is approved and you have reviewed the network's requirements.
- Update `privacy.html` when adding ads, analytics, cookies or other third-party services.
- Do not click your own ads or buy fake traffic.

## Notes
- The PDF re-save tool is not a true compression engine; re-saving can sometimes increase file size.
- PDF features and QR generation depend on third-party CDN scripts. The other tools are implemented in browser JavaScript.
- This starter does not promise search rankings, traffic or ad revenue.
