# SmartToolbox — GitHub Pages upload

## Files
Upload every file in this folder directly into the **root** of your `smarttoolbox2` repository:
- `index.html`
- `about.html`
- `contact.html`
- `privacy.html`
- `404.html`
- `styles.css`
- `app.js`
- `robots.txt`
- `sitemap.xml`

Do not upload the older `index(1).html` version. This package uses the newer homepage that matches `app.js` and `styles.css`.

## Before publishing
1. In `contact.html`, replace `YOUR-EMAIL@example.com` with an email address you monitor.
2. Review `privacy.html` and make sure it accurately describes the services and advertising/analytics scripts you actually use.
3. Check that the canonical URL and sitemap point to `https://ytkids7867-ship-it.github.io/smarttoolbox2/`.

## Enable GitHub Pages
1. Open `https://github.com/ytkids7867-ship-it/smarttoolbox2`
2. Choose **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch **main** and folder **/(root)**, then click **Save**.
5. Wait for the Pages deployment to finish.

Expected website: https://ytkids7867-ship-it.github.io/smarttoolbox2/

GitHub Pages serves static websites. Confirm GitHub's current terms for your intended use, including advertising, before relying on it for monetization.
